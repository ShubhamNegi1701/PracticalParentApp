Adapted from Cornell University's Department of Computer Science
Java Code Style Guidelines
by David Gries
http://www.cs.cornell.edu/courses/JavaAndDS/JavaStyle.html
